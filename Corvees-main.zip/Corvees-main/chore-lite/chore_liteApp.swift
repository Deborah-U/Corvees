//
//  chore_liteApp.swift
//  chore-lite
//
//  Created by Kristen Chen on 5/1/21.
//

import SwiftUI

@main
struct chore_liteApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
